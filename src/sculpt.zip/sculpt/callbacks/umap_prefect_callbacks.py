"""
Working UMAP callback for Prefect 3.x that shows flows in UI
Save as: sculpt/callbacks/umap_prefect_callbacks.py
"""
from dash import callback, Input, Output, State, html, dcc, ALL, no_update
import plotly.express as px
import pandas as pd
from prefect import serve, flow
import asyncio
import threading
import uuid
from sculpt.flows.umap_flow import umap_analysis_flow

# Store for running flows
FLOW_RESULTS = {}


def run_flow_async(flow_id, **kwargs):
    """Run flow in background thread - it WILL show in Prefect UI"""
    try:
        # Run the flow - this automatically registers with Prefect server
        result = umap_analysis_flow(**kwargs)
        FLOW_RESULTS[flow_id] = {"status": "completed", "result": result}
    except Exception as e:
        FLOW_RESULTS[flow_id] = {"status": "failed", "error": str(e)}


@callback(
    Output("umap-graph-container", "children"),
    Output("debug-output", "children", allow_duplicate=True),
    Output("combined-data-store", "data", allow_duplicate=True),
    Output("umap-quality-metrics", "children", allow_duplicate=True),
    Output("umap-flow-status", "data"),
    Input("run-umap", "n_clicks"),
    Input("umap-check-interval", "n_intervals"),
    State("stored-files", "data"),
    State("umap-file-selector", "value"),
    State("num-neighbors", "value"),
    State("min-dist", "value"),
    State("sample-frac", "value"),
    State({"type": "feature-selector-graph1", "category": ALL}, "value"),
    State("umap-flow-status", "data"),
    prevent_initial_call=True,
)
def run_umap_analysis(
    n_clicks,
    n_intervals,
    stored_files,
    selected_ids,
    num_neighbors,
    min_dist,
    sample_frac,
    selected_features_list,
    flow_status
):
    """Run UMAP analysis with Prefect 3.x"""
    
    ctx = dash.callback_context
    if not ctx.triggered:
        return no_update, no_update, no_update, no_update, no_update
    
    triggered = ctx.triggered[0]['prop_id'].split('.')[0]
    
    # Start new flow when button clicked
    if triggered == "run-umap":
        if not stored_files or not selected_ids:
            return (
                html.Div("No files selected", style={"color": "red"}),
                "No files to process",
                no_update,
                html.Div("No metrics"),
                no_update
            )
        
        # Generate unique flow ID
        flow_id = str(uuid.uuid4())[:8]
        
        # Initialize status
        FLOW_RESULTS[flow_id] = {"status": "running"}
        
        # Run flow in background thread so UI doesn't block
        thread = threading.Thread(
            target=run_flow_async,
            kwargs={
                "flow_id": flow_id,
                "stored_files": stored_files,
                "selected_ids": selected_ids,
                "num_neighbors": num_neighbors,
                "min_dist": min_dist,
                "sample_frac": sample_frac,
                "selected_features_list": selected_features_list,
                "dbscan_eps": 0.5,
                "dbscan_min_samples": 5
            }
        )
        thread.daemon = True
        thread.start()
        
        return (
            html.Div([
                html.H5("🔄 UMAP Analysis Started!", style={"color": "blue"}),
                html.P("Check Prefect UI at http://127.0.0.1:4200"),
                html.P(f"Flow ID: {flow_id}")
            ]),
            f"Flow {flow_id} started",
            no_update,
            html.Div("Processing..."),
            {"flow_id": flow_id}  # Store flow ID for checking
        )
    
    # Check flow status on interval
    elif triggered == "umap-check-interval" and flow_status and "flow_id" in flow_status:
        flow_id = flow_status["flow_id"]
        
        if flow_id not in FLOW_RESULTS:
            return no_update, no_update, no_update, no_update, no_update
        
        flow_info = FLOW_RESULTS[flow_id]
        
        if flow_info["status"] == "running":
            # Still running
            return no_update, no_update, no_update, no_update, flow_status
        
        elif flow_info["status"] == "completed":
            result = flow_info["result"]
            
            if result and result.get('success'):
                # Create visualization
                umap_df = result['umap_df']
                
                fig = px.scatter(
                    umap_df,
                    x='UMAP1',
                    y='UMAP2',
                    color='Cluster',
                    title=f"UMAP Visualization ({len(umap_df)} points, {result['clustering_info']['n_clusters']} clusters)",
                    color_continuous_scale='Viridis'
                )
                
                fig.update_layout(
                    xaxis_title="UMAP Component 1",
                    yaxis_title="UMAP Component 2",
                    height=600,
                    hovermode='closest'
                )
                
                # Metrics
                clustering_info = result['clustering_info']
                metrics = html.Div([
                    html.H6("Clustering Metrics:"),
                    html.Ul([
                        html.Li(f"Number of clusters: {clustering_info['n_clusters']}"),
                        html.Li(f"Noise points: {clustering_info['n_noise']}"),
                        html.Li(f"Computation time: {result['metadata']['computation_time']:.2f}s")
                    ])
                ])
                
                # Clean up
                del FLOW_RESULTS[flow_id]
                
                return (
                    dcc.Graph(figure=fig),
                    f"✅ Completed in {result['metadata']['computation_time']:.2f}s",
                    result['combined_df'].to_dict('records'),
                    metrics,
                    None  # Clear flow status
                )
            else:
                return (
                    html.Div("Flow completed but no results", style={"color": "orange"}),
                    "No results",
                    no_update,
                    html.Div("No metrics"),
                    None
                )
        
        elif flow_info["status"] == "failed":
            error_msg = flow_info.get("error", "Unknown error")
            
            # Clean up
            del FLOW_RESULTS[flow_id]
            
            return (
                html.Div(f"Error: {error_msg}", style={"color": "red"}),
                f"Failed: {error_msg}",
                no_update,
                html.Div("Error occurred"),
                None
            )
    
    return no_update, no_update, no_update, no_update, no_update